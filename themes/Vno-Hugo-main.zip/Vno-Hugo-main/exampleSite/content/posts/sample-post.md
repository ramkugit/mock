---
layout: post
tags: ["Say Hi", "Hugo"]
title: "Sample Post"
date: 2021-07-19T07:28:17+08:00
math: false
draft: false
---
You’ll find this post in your `posts` directory. Go ahead and edit it and re-build the site to see your changes. You can rebuild the site in many different ways, but the most common way is to run `hugo serve`, which launches a web server and auto-regenerates your site when a file is updated.

To add new posts, simply run:
```bash
$ hugo new posts/my-sample-post.md
```
And you shall see the my-sample-post.md file in `posts` directory, just edit the front matter and content as you like. Take a look at the source for this post to get an idea about how it works.

